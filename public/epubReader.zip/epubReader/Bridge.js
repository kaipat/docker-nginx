//
//  Bridge.js
//
//  Created by Heberti Almeida on 06/05/15.
//  Copyright (c) 2015 Folio Reader. All rights reserved.
//

// What is CFI ?
// The CFI class implements an EPUB 3 Content Fragment Identifier.
// A CFI is similar in principle to a DOMRange: it identifies a particular location within a publication.

var Direction = Object.freeze({
    VERTICAL: "VERTICAL",
    HORIZONTAL: "HORIZONTAL"
});

var DisplayUnit = Object.freeze({
    PX: "PX",
    DP: "DP",
    CSS_PX: "CSS_PX"
});

var MOJiTheme = {
    LIGHT: "theme-light",
    DARK: "theme-dark",
    CUSTOM: "theme-customized"
};

var FURIGANA_TYPE = {
    HIRAGANA: 0,
    ROMAJI: 1,
    NONE: 2,
    OWN: 3
};

var Api = {
    onLoaded: 'onJsLoaded',
    clickWord: 'clickMOJiArticleContent',
    // storeLastReadCfi: 'storeLastReadCfi',
    setCurrentInnerPage: 'setCurrentInnerPage',
    setHorizontalPageCount: 'setHorizontalPageCount',
    setScrollEnable: 'setScrollEnable'
};

var NotationMarkFilter = '.moji-toolkit-org, ruby, .moji-notation';

var scrollWidth;
var horizontalInterval;
var horizontalIntervalPeriod = 100;
var horizontalIntervalCounter = 0;
var horizontalPageCalCounter = 0;
var horizontalIntervalLimit = 10;

var viewportRect;
var intersectNode;

var isIOS = false;
var isAndroid = false;
var isFirstLoad = true;
var withNotation = true;
var currentCFI = '';
var currentPageIndex = 0;
var currentPageCount = 0;

//#region export
/**
 * @description: entry
 * @return {*}
 * @param { String } detailsInfo json string
 * @param { String } platform ios | android
 * @param { String } lastCfi string
 */
function Main(detailsInfo) {
    var platform = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';
    var lastCfi = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
    var sentenceListJson = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : '';

    isIOS = platform == 'ios';
    isAndroid = platform == 'android';
    initHorizontalDirection(lastCfi);


    var info = JSON.parse(detailsInfo);
    var _info$themeName = info.themeName,
        themeName = _info$themeName === undefined ? MOJiTheme.LIGHT : _info$themeName,
        _info$fontSize = info.fontSize,
        fontSize = _info$fontSize === undefined ? 1 : _info$fontSize;


    MOJiArticleDetailSetFontSize(fontSize, false);
    MOJiArticleDetailDidSetTheme(themeName);
    // withNotation = (null != document.body.querySelector(NotationMarkFilter))
    // withNotation && MOJiArticleDidChangeNotationMode(furiganaType, false)

    try {
        var sentenceList = sentenceListJson && JSON.parse(sentenceListJson) || [];
        initManySentence(sentenceList);
    } catch (error) {}

    setBodyOpacity(1);

    window.onresize = function () {
        onMounted();
    };
    isIOS && listenerOnselectionchange();
    registerImageClickAction();
}

/**
 * @description: 翻页后计算阅读进度(如果首元素跨多个页面，将记录元素开始位置)
 * @return { String } cfi
 * @param { String } currentViewportRect
 */
function computeLastReadCfi() {
    viewportRect = getCurrentDOMRect();
    var node = getFirstVisibleNode(document.body) || intersectNode || document.body;
    var cfi = getNodeCfi(node);

    viewportRect = null;
    intersectNode = null;

    // req(Api.storeLastReadCfi, cfi)

    currentCFI = cfi;
    return cfi;
}

function getNodeCfi(node) {
    var cfi = void 0;
    if (node.nodeType === Node.TEXT_NODE) {
        cfi = EPUBcfi.Generator.generateCharacterOffsetCFIComponent(node, 0);
    } else {
        cfi = EPUBcfi.Generator.generateElementCFIComponent(node);
    }

    cfi = EPUBcfi.Generator.generateCompleteCFI("/0!", cfi);

    return cfi;
}

/**
 * @description: config
 * @return { null }
 * @param { String } theme
 */
function MOJiArticleDetailDidSetTheme() {
    var theme = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : MOJiTheme.LIGHT;

    document.body.setAttribute('_t', theme);
}

/**
 * @description: config
 * @return { null }
 * @param { String | Number } size
 */
function MOJiArticleDetailSetFontSize() {
    var size = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;
    var isReload = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;

    document.body.style.setProperty('--font-size', size);
    isReload && onMounted();
}

/**
 * @description: config
 * @return { null }
 * @param { String | Number } furiganaType
 */
function MOJiArticleDidChangeNotationMode() {
    var furiganaType = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : FURIGANA_TYPE.NONE;
    var isReload = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
}
// if (!withNotation) return

// document.body.setAttribute('f_m', furiganaType)
// showRoma = furiganaType == FURIGANA_TYPE.ROMAJI
// showHira = furiganaType == FURIGANA_TYPE.HIRAGANA

// let rtList = document.querySelectorAll('.moji-notation ruby rt')
// for (let index = 0, len = rtList.length; index < len; index++) {
//     let rt = rtList[index]
//     let rtValue = showRoma ? rt.getAttribute('roma') : showHira ? rt.getAttribute('hiragana') : ''
//     rt.setAttribute('data-rt', rtValue)
// }

// isReload && onMounted()


//#endregion

// Class manipulation
function hasClass(ele, cls) {
    return !!ele.className.match(new RegExp('(\\s|^)' + cls + '(\\s|$)'));
}

function addClass(ele, cls) {
    if (!hasClass(ele, cls)) ele.className += " " + cls;
}

function removeClass(ele, cls) {
    if (hasClass(ele, cls)) {
        var reg = new RegExp('(\\s|^)' + cls + '(\\s|$)');
        ele.className = ele.className.replace(reg, ' ');
    }
}

function horizontalRecheck(lastCfi) {
    // if (window.scrollWidth != document.documentElement.scrollWidth) {
    // Rare condition
    // This might happen when document.documentElement.scrollWidth gives incorrect value
    // when the webview is busy re-drawing contents.
    //console.log("-> horizontalIntervalCounter = " + horizontalIntervalCounter);
    console.warn("-> scrollWidth changed from " + window.scrollWidth + " to " + document.documentElement.scrollWidth);
    horizontalIntervalCounter++;

    var pageCount = postInitHorizontalDirection();
    if (pageCount != currentPageCount) {
        currentPageCount = pageCount;
    } else if (horizontalIntervalCounter >= horizontalIntervalLimit) {
        clearInterval(horizontalInterval);
        req(Api.setHorizontalPageCount, currentPageCount);
        if (lastCfi) {
            currentCFI = lastCfi;
            scrollToCfi(currentCFI);
        }
    } else {
        horizontalPageCalCounter++;
        if (horizontalPageCalCounter > 6) {
            clearInterval(horizontalInterval);
            req(Api.setHorizontalPageCount, currentPageCount);
            if (lastCfi) {
                currentCFI = lastCfi;
                scrollToCfi(currentCFI);
            }
        }
    }
    // }
}

function initHorizontalDirection(lastCfi) {
    horizontalIntervalCounter = 0;
    horizontalPageCalCounter = 0;

    preInitHorizontalDirection();
    postInitHorizontalDirection();

    horizontalInterval = setInterval(function(){horizontalRecheck(lastCfi)}, horizontalIntervalPeriod);

    autoZoomCover();
}

function preInitHorizontalDirection() {
    var htmlElement = document.getElementsByTagName('html')[0];
    var bodyElement = document.getElementsByTagName('body')[0];
    // Required when initHorizontalDirection() is called multiple times.
    // Currently it is called only once per page.
    htmlElement.style.width = null;
    bodyElement.style.width = null;
    htmlElement.style.height = null;
    bodyElement.style.height = null;

    var bodyStyle = bodyElement.currentStyle || window.getComputedStyle(bodyElement);
    var paddingTop = parseInt(bodyStyle.paddingTop, 10);
    var paddingRight = parseInt(bodyStyle.paddingRight, 10);
    var paddingBottom = parseInt(bodyStyle.paddingBottom, 10);
    var paddingLeft = parseInt(bodyStyle.paddingLeft, 10);

    //document.documentElement.clientWidth is window.innerWidth excluding x scrollbar width
    var pageWidth = document.documentElement.clientWidth - (paddingLeft + paddingRight);
    //document.documentElement.clientHeight is window.innerHeight excluding y scrollbar height
    var pageHeight = document.documentElement.clientHeight - (paddingTop + paddingBottom);

    bodyElement.style.webkitColumnGap = paddingLeft + paddingRight + 'px';
    bodyElement.style.webkitColumnWidth = pageWidth + 'px';
    bodyElement.style.columnFill = 'auto';

    htmlElement.style.height = pageHeight + (paddingTop + paddingBottom) + 'px';
    bodyElement.style.height = pageHeight + 'px';
}

function postInitHorizontalDirection() {
    var htmlElement = document.getElementsByTagName('html')[0];
    var bodyElement = document.getElementsByTagName('body')[0];
    var bodyStyle = bodyElement.currentStyle || window.getComputedStyle(bodyElement);
    // var paddingTop = parseInt(bodyStyle.paddingTop, 10)
    var paddingRight = parseInt(bodyStyle.paddingRight, 10);
    // var paddingBottom = parseInt(bodyStyle.paddingBottom, 10)
    var paddingLeft = parseInt(bodyStyle.paddingLeft, 10);
    var scrollingElement = bodyOrHtml();
    // var clientWidth = document.documentElement.clientWidth
    var clientWidth = scrollingElement.clientWidth;

    // var scrollWidth = document.documentElement.scrollWidth
    var scrollWidth = scrollingElement.scrollWidth;
    //console.log("-> document.documentElement.offsetWidth = " + document.documentElement.offsetWidth);
    if (scrollWidth > clientWidth && scrollWidth > document.documentElement.offsetWidth) {
        scrollWidth += paddingRight;
    }
    var newBodyWidth = scrollWidth - (paddingLeft + paddingRight);
    window.scrollWidth = scrollWidth;

    // pageCount deliberately rounded instead of ceiling to avoid any unexpected error
    var pageCount = Math.round(scrollWidth / clientWidth);
    var pageCountFloat = scrollWidth / clientWidth;

    // 单页设置width后页面宽度>屏幕宽度，导致横向滚动
    if (pageCount > 1) {
        htmlElement.style.width = scrollWidth + 'px';
        bodyElement.style.width = newBodyWidth + 'px';
    }

    if (pageCount != pageCountFloat) {
        console.warn("-> pageCount = " + pageCount + ", pageCountFloat = " + pageCountFloat + ", Something wrong in pageCount calculation");
    }

    return pageCount;
}

function autoZoomCover() {
    var body = document.body;
    var imgs = body.querySelectorAll('svg, img');
    var bodyStyle = body.currentStyle || window.getComputedStyle(body);
    var maxWidth = parseInt(bodyStyle.columnWidth, 10);
    var maxHeight = body.clientHeight;
    if (imgs.length == 1) {
        var cover = imgs[0];
        if (cover.nodeName == 'svg') zoomSvg(cover);else if (cover.nodeName == 'img') zoomImg(cover);
    }

    function zoomSvg(svg) {
        svg.setAttribute('viewBox', "0 0 " + maxWidth + " " + maxHeight);
        var image = svg.querySelector('image');
        image && image.setAttribute('width', '100%');
        image && image.setAttribute('height', '100%');
    }

    function zoomImg(img) {
        img.style.setProperty('max-width', maxWidth + 'px', 'important');
        img.style.setProperty('max-height', maxHeight + 'px', 'important');
    }
}

// TODO -> Check if this is required?
function bodyOrHtml() {
    if ('scrollingElement' in document) {
        return document.scrollingElement;
    }
    // Fallback for legacy browsers
    if (navigator.userAgent.indexOf('WebKit') != -1) {
        return document.body;
    }
    return document.documentElement;
}

/**
 * @param {(Element|Text|Range)} nodeOrRange
 * @returns {(Element|Text|Range)} nodeOrRange
 */
function scrollToNodeOrRange(nodeOrRange) {
    var pageIndex = getPageIndexByNodeOrRange(nodeOrRange);
    // var newScrollLeft = clientWidth * pageIndex
    //console.log("-> newScrollLeft = " + newScrollLeft);
    // scrollingElement.scrollLeft = newScrollLeft
    scrollToPageIndex(pageIndex);
    // break
    // }

    // return nodeOrRange
    // return pageIndex
}

function getPageIndexByNodeOrRange(nodeOrRange) {
    var scrollingElement = bodyOrHtml();
    // var direction = FolioWebView.getDirection()

    // For Direction.VERTICAL
    // var nodeOffsetTop, nodeOffsetHeight

    // For Direction.HORIZONTAL
    var nodeOffsetLeft;

    if (nodeOrRange instanceof Range || nodeOrRange.nodeType === Node.TEXT_NODE) {

        var rect;
        if (nodeOrRange.nodeType && nodeOrRange.nodeType === Node.TEXT_NODE) {
            var range = document.createRange();
            range.selectNode(nodeOrRange);
            rect = RangeFix.getBoundingClientRect(range);
        } else {
            rect = RangeFix.getBoundingClientRect(nodeOrRange);
        }
        // nodeOffsetTop = scrollingElement.scrollTop + rect.top
        // nodeOffsetHeight = rect.height
        nodeOffsetLeft = scrollingElement.scrollLeft + rect.left;
    } else if (nodeOrRange.nodeType === Node.ELEMENT_NODE) {

        // nodeOffsetTop = nodeOrRange.offsetTop
        // nodeOffsetHeight = nodeOrRange.offsetHeight
        nodeOffsetLeft = nodeOrRange.offsetLeft;
    } else {
        throw "-> Illegal Argument Exception, nodeOrRange -> " + nodeOrRange;
    }

    // TODO 暂时先做水平翻页
    // switch (direction) {

    // case Direction.VERTICAL:
    //     var topDistraction = FolioWebView.getTopDistraction(DisplayUnit.DP)
    //     var pageTop = scrollingElement.scrollTop + topDistraction
    //     var pageBottom = scrollingElement.scrollTop + document.documentElement.clientHeight
    //         - FolioWebView.getBottomDistraction(DisplayUnit.DP)

    //     var elementTop = nodeOffsetTop - 20
    //     elementTop = elementTop < 0 ? 0 : elementTop
    //     var elementBottom = nodeOffsetTop + nodeOffsetHeight + 20
    //     var needToScroll = (elementTop < pageTop || elementBottom > pageBottom)

    //     //console.log("-> topDistraction = " + topDistraction);
    //     //console.log("-> pageTop = " + pageTop);
    //     //console.log("-> elementTop = " + elementTop);
    //     //console.log("-> pageBottom = " + pageBottom);
    //     //console.log("-> elementBottom = " + elementBottom);

    //     if (needToScroll) {
    //         var newScrollTop = elementTop - topDistraction
    //         newScrollTop = newScrollTop < 0 ? 0 : newScrollTop
    //         //console.log("-> Scrolled to = " + newScrollTop);
    //         scrollingElement.scrollTop = newScrollTop
    //     }
    //     break

    // case Direction.HORIZONTAL:
    var clientWidth = scrollingElement.clientWidth; //document.documentElement.clientWidth
    var pageIndex = Math.floor(nodeOffsetLeft / clientWidth);
    return pageIndex;
}

function scrollToPageIndex(pageIndex) {
    currentPageIndex = pageIndex;
    req(Api.setCurrentInnerPage, pageIndex);
}

function getCurrentDOMRect() {
    var scrollElement = bodyOrHtml();
    var w = scrollElement.clientWidth;
    var h = scrollElement.clientHeight;
    var x = 0;
    var y = 0;
    return new DOMRect(x, y, w, h);
}

/**
 * Gets the first partially or completely visible node in viewportRect
 * @param {Node} node Accepts {@link Element} or {@link Text}
 * @returns {(Node|null)} Returns {@link Element} or {@link Text} or null
 */
function getFirstVisibleNode(node) {

    var range = document.createRange();
    range.selectNode(node);
    var rect = RangeFix.getBoundingClientRect(range);
    if (rect == null) return null;

    var intersects = rectIntersects(viewportRect, rect);
    var contains = rectContains(viewportRect, rect);

    if (contains) {
        // node's rect is completely inside viewportRect.
        return node;
    } else if (intersects) {

        var childNodes = node.childNodes;
        for (var i = 0; i < childNodes.length; i++) {

            // EPUB CFI ignores nodes other than ELEMENT_NODE and TEXT_NODE
            // http://www.idpf.org/epub/linking/cfi/epub-cfi.html#sec-path-child-ref

            if (childNodes[i].nodeType === Node.ELEMENT_NODE || childNodes[i].nodeType === Node.TEXT_NODE) {
                var childNode = getFirstVisibleNode(childNodes[i]);
                if (childNode) {
                    return childNode;
                }
            }
        }

        // No children found or no child's rect completely inside viewportRect,
        // so returning this node as it's rect intersected with viewportRect.
        intersectNode = node;
    }
    return null;
}

/**
 * @description: 翻到元素所在页面
 * @return { Number } ios only
 * @param { String } cfi
 */
function scrollToCfi(cfi) {
    if (!cfi) return;

    try {
        var $node = EPUBcfi.Interpreter.getTargetElement(cfi, document);
        scrollToNodeOrRange($node[0]);
    } catch (e) {
        console.error("-> " + e);
    }
}

/**
 * Returns true iff the two specified rectangles intersect. In no event are
 * either of the rectangles modified.
 *
 * @param {DOMRect} a The first rectangle being tested for intersection
 * @param {DOMRect} b The second rectangle being tested for intersection
 * @returns {boolean} returns true iff the two specified rectangles intersect.
 */
function rectIntersects(a, b) {
    return a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom;
}

/**
 * Returns true iff the specified rectangle b is inside or equal to
 * rectangle b. An empty rectangle never contains another rectangle.
 *
 * @param {DOMRect} a The rectangle being tested whether rectangle b is inside this or not.
 * @param {DOMRect} b The rectangle being tested for containment.
 * @returns {boolean} returns true iff the specified rectangle r is inside or equal to this rectangle
 */
function rectContains(a, b) {
    // check for empty first
    return a.left < a.right && a.top < a.bottom
    // now check for containment
    && a.left <= b.left && a.top <= b.top && a.right >= b.right && a.bottom >= b.bottom;
}

function setBodyOpacity() {
    var value = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 1;

    document.body.style.opacity = value;
}

/**
 * @description: 发送请求至app
 * @return {*}
 * @param { string } method which defined in app
 * @param { object | String } params ios只能传String
 */
function req(method) {
    var params = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '';

    try {
        if (isIOS) {
            window.webkit.messageHandlers[method].postMessage(params);
        } else {
            ReaderJsInterface[method](params);
        }
    } catch (error) {
        // console.error(error)
    }
}

function onMounted() {
    initHorizontalDirection(currentCFI);
    // scrollToCfi(currentCFI);
}

$(function () {
    window.ssReader = Class({
        $singleton: true,

        init: function init() {
            rangy.init();
        },
        base64encode: function base64encode(str) {
            return btoa(unescape(encodeURIComponent(str)));
        },

        base64decode: function base64decode(str) {
            return decodeURIComponent(escape(atob(str)));
        },
        clearSelection: function clearSelection() {
            if (window.getSelection) {
                if (window.getSelection().empty) {
                    // Chrome
                    window.getSelection().empty();
                } else if (window.getSelection().removeAllRanges) {
                    // Firefox
                    window.getSelection().removeAllRanges();
                }
            } else if (document.selection) {
                // IE?
                document.selection.empty();
            }
        }
    });

    if (typeof ssReader !== "undefined") {
        ssReader.init();
    }
    $("span[a-token], ruby").click(function (e) {
        let selectedNode = e.target;
        let isHasParent = getParent();
        let res = isHasParent(selectedNode, function(parentNode) {
            let LowerA = parentNode && parentNode.tagName && parentNode.tagName.toLowerCase();
            return LowerA === 'a'
        })
        if (res) return
        var curTagText = selectedNode.textContent;

        curTagText && doSearch(selectedNode, curTagText);
    });
    // function isWord (text) {
    //     return text && text.match(/[A-Za-z0-9|ぁ-んァ-ヶ|\u4e00-\u9fa5]/)
    // }
});
function doSearch(node, text) {
    window.getSelection().removeAllRanges();
    node.classList.add('on-click-word');
    setTimeout(function () {
        node.classList.remove('on-click-word');
    }, 500);
    req(Api.clickWord, text);
}

// 递归寻找父元素 直到满足条件
function getParent(level = 100) {
    let index = 0;
    function getP(el, fn) {
        index++;
        if (index >= level) {
            return false;
        }
        let parentNode = el.parentNode;
        if(!parentNode) return false
        if (fn(parentNode)) {
            return parentNode
        } else {
            return getP(parentNode, fn);
        }
    }
    return getP
}


// document.onload = function () {
//     preInitHorizontalDirection();
// };

window.onload = function () {
    preInitHorizontalDirection();
    req(Api.onLoaded);
};

document.onreadystatechange = function () {
    if (document.readyState == 'complete') {
        // 此时无平台信息，只能用ua做区分
        if (/iP(hone|od|ad)|Macintosh/.test(navigator.userAgent)) {
            window.webkit.messageHandlers.onJsLoaded.postMessage('');
        } else {
            ReaderJsInterface.onJsLoaded();
        }
        document.onreadystatechange = null;
    }
};

window.onbeforeunload = function () {
    horizontalInterval && clearInterval(horizontalInterval);
};