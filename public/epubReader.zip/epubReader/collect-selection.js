/*
 * Copyright © Hugecore Information Technology (Guangzhou) Co.,Ltd. All rights reserved
 * @Date: 2023-01-30 17:26:34
 * @Author: Jing
 * @LastEditors: rin
 * @LastEditTime: 2023-02-21 18:35:28
 * @FilePath: /js-for-native-mojidict-app/A_collectSelection/collect-selection.js
 * @Description:
 */
// #region defined
var sentenceMap = new Map();
var highlightMap = new Map();
var currentEnableScroll = true;

var highlighter = new Highlighter({
    exceptSelectors: ['pre', 'code']
});
// highlighter.on(Highlighter.event.CLICK, function (data) {
//     let sentenceId = highlightMap.get(data.id)
//     errorTips('click hl: ' + sentenceId)
//     // sentenceId && req(Api.showMenu, sentenceId)
// })

// #endregion

// #region test case
function debughl() {
    var param = collectSentence();
    if (!param) return;

    var underlinePosition = param.split('$')[0];
    collectSuccessCallBack(underlinePosition, '19873673', new Date().getTime());
}

function debugremove() {
    cancelCollectSuccessCallBack('19873673');
}

// #endregion

// #region export
function initManySentence(sentenceList) {
    for (var index = 0, len = sentenceList.length; index < len; index++) {
        var s = sentenceList[index];
        collectSuccessCallBack(s.underlinePosition, s.id, s.createTime);
    }
}

function collectSentence() {
    var source = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'article';

    var range = getDomRange();
    if (!range) return false;

    var underlinePosition = getPosition();

    if (source == 'book' && EPUBcfi) {
        var position = underlinePosition.split('#');
        if (position.length != 4) {
            return;
        }
        var startMOJiId = position[0];
        var startOffset = position[1];
        var startContainer = getTextChildByOffset(document.querySelector('[moji-id="' + startMOJiId + '"]'), startOffset);
        var locationCfi = getNodeCfi(startContainer.node);
        return underlinePosition + '$' + locationCfi;
    } else if (source == 'article') {
        return underlinePosition;
    } else {
        return false;
    }
}

function collectSuccessCallBack(underlinePosition, sentenceId, sentenceCreateTime) {
    try {
        var position = underlinePosition.split('#');
        if (position.length != 4) {
            return;
        }

        var startMOJiId = position[0];
        var endMOJiId = position[2];
        var startOffset = position[1];
        var endOffset = position[3];
        var startContainer = getTextChildByOffset(document.querySelector('[moji-id="' + startMOJiId + '"]'), startOffset);
        var endContainer = getTextChildByOffset(document.querySelector('[moji-id="' + endMOJiId + '"]'), endOffset);

        setDomRange(startContainer.node, startContainer.offset, endContainer.node, endContainer.offset);

        var hlId = setHightLight();
        hlId && saveSentenceCache(sentenceId, hlId, sentenceCreateTime);

        setTimeout(function () {
            removeSelection();
        }, 200);
    } catch (error) {
        console.error(error);
    }
}

function cancelCollectSuccessCallBack(sentenceId) {
    var s = sentenceMap.get(sentenceId);
    s && removeHighlight(s.hlId);
    s && removeSentenceCache(sentenceId, s.hlId);
}

function getHighLightSentenceId() {
    var range = getDomRange();
    if (!range) return null;

    var hlId_s = getHlId(range.startContainer);
    var hlId_e = getHlId(range.endContainer);
    if (hlId_s == hlId_e) {
        var sentenceId = highlightMap.get(hlId_s);
        return sentenceId;
    } else {
        return null;
    }
}

// #endregion

// #region helper
// function registerLongPressEvent (container) {
//     let startTime = 0

//     container.ontouchstart = function () {
//         startPressCallBack()
//         container.ontouchend = finishPressCallBack
//         container.onmousedown = null
//         container.onmouseup = null
//     }
//     container.onmousedown = function () {
//         startPressCallBack()
//         container.onmouseup = finishPressCallBack
//     }

//     function startPressCallBack () {
//         startTime = new Date().getTime()
//     }


//     function finishPressCallBack (e) {
//         let endTime = new Date().getTime()
//         if (endTime - startTime > 300) {
//             let target = e.target || e.changedTouches[0].target
//             let hlId = getHlId(target)
//             if (hlId) {
//                 e.stopPropagation()
//                 e.preventDefault()
//                 let sentenceId = highlightMap.get(hlId)
//                 try {
//                     sentenceId && req(Api.showMenu, sentenceId)
//                 } catch (error) {

//                 }
//                 setTimeout(() => {
//                     removeSelection()
//                 }, 200)
//             }

//         }
//     }
// }

function getHlId(el) {
    if (el.nodeType != document.TEXT_NODE && (el.hasAttribute('data-highlight-id') || el.hasAttribute('data-highlight-id-extra'))) {
        var extra = el.getAttribute('data-highlight-id-extra');
        return extra && extra.split(';').reverse()[0] || el.getAttribute('data-highlight-id');
    } else if (document.body.contains(el.parentNode)) {
        return getHlId(el.parentNode);
    } else {
        return false;
    }
}

function saveSentenceCache(sId, hlId, sentenceCreateTime) {
    sentenceMap.set(sId, {
        hlId: hlId,
        createTime: sentenceCreateTime
    });
    highlightMap.set(hlId, sId);
}

function removeSentenceCache(sId, hlId) {
    sId && sentenceMap.delete(sId);
    hlId && highlightMap.delete(hlId);
}

function setHightLight() {
    var range = getDomRange();
    if (!range) return false;

    var highData = highlighter.fromRange(range);
    // console.log('创建例句', highData.text)
    return highData.id;
}
function removeHighlight(id) {
    highlighter.remove(id);
}

function getDomRange() {
    var selection = window.getSelection();
    if (selection.isCollapsed) {
        return null;
    }
    return selection.getRangeAt(0);
}
function setDomRange(nodeA, offsetA, nodeB, offsetB) {
    removeSelection();

    var selection = window.getSelection();
    var range = document.createRange();
    range.setStart(nodeA, offsetA);
    range.setEnd(nodeB, offsetB);
    selection.addRange(range);
    return range;
}

function removeSelection() {
    window.getSelection().removeAllRanges();
}

/**
 * @description: 处理选区，限制选区在段落内
 * @return {*}
 */
function handlerSelection() {
    var range = getDomRange();
    if (!range) return false;

    var startContainer = range.startContainer,
        startOffset = range.startOffset,
        endContainer = range.endContainer,
        endOffset = range.endOffset;

    var _getRangeParentNode = getRangeParentNode(range),
        startParent = _getRangeParentNode.startParent,
        endParent = _getRangeParentNode.endParent;

    if (startParent && endParent && endParent == startParent) {
        // console.log('是一个范围内的数据', range)
        return startParent;
    } else if (startParent && endParent != startParent) {
        // console.log('不是一个范围内的数据，修改选区')
        var endNode = findLastTextNode(startParent.lastChild);
        setDomRange(startContainer, startOffset, endNode, endNode.nodeValue.length);
        return startContainer;
    } else if (!startParent && endParent) {
        var startNode = findFirstTextNode(endParent.firstChild);
        setDomRange(startNode, 0, endContainer, endOffset);
        return startNode;
    } else {
        // 首尾元素不符合规范
        return false;
    }

    /**
     * @description: 找到节点末尾的文本节点
     * @return {*}
     * @param {*} node
     */
    function findLastTextNode(node) {
        if (node.nodeType === document.TEXT_NODE) {
            return node;
        } else {
            return findLastTextNode(node.lastChild);
        }
    }

    function findFirstTextNode(node) {
        if (node.nodeType === document.TEXT_NODE) {
            return node;
        } else {
            return findFirstTextNode(node.firstChild);
        }
    }
}

/**
 * @description: 获取选区开始与结束节点的P/DIV祖先节点
 * @return {*}
 * @param {*} range
 */
function getRangeParentNode(range) {
    if (range) {
        return {
            startParent: getBlockNode(range.startContainer),
            endParent: getBlockNode(range.endContainer)
        };
    } else {
        return {
            startParent: null,
            endParent: null
        };
    }
}
/**
 * @description: 获取为P/DIV的父标签
 * @return {*}
 * @param {*} node
 */
function getBlockNode(node) {
    var returnVal = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : null;

    if (!returnVal && node.nodeType != document.TEXT_NODE && node.getAttribute('moji-id')) {
        returnVal = node;
    }
    if (isSource(node.className)) {
        return null;
    } else if (node.parentNode.nodeName == 'BODY') {
        return returnVal;
    } else {
        return getBlockNode(node.parentNode, returnVal);
    }

    function isSource(className) {
        return (/moji-article-source-item | moji-article-voter | moji-article-link-item/g.test(className)
        );
    }
}

function getPosition() {
    var range = getDomRange();
    var startContainer = range.startContainer,
        endContainer = range.endContainer;

    var startParentNode = getMojiIdNode(range.startContainer);
    //   console.log('***', startParentNode)
    var endParentNode = getMojiIdNode(range.endContainer);
    //   console.log('***', endParentNode)

    var startPosition = startParentNode.getAttribute('moji-id') + '#' + (getTextPreOffset(startParentNode, startContainer) + range.startOffset);
    var endPosition = endParentNode.getAttribute('moji-id') + '#' + (getTextPreOffset(endParentNode, endContainer) + range.endOffset);
    return startPosition + '#' + endPosition;
}

function getMojiIdNode(node) {
    if (node.nodeType == Node.TEXT_NODE || !node.getAttribute('moji-id')) {
        return getMojiIdNode(node.parentNode);
    } else {
        // console.dir('getMojiIdNode', node)
        return node;
    }
}
function getTextPreOffset(root, text) {
    // console.log('getTextPreOffset', root)
    // console.log('getTextPreOffset', text)
    var nodeStack = [];
    var curNode = root;
    var offset = 0;
    while (curNode) {
        var children = curNode.childNodes;
        for (var i = children.length - 1; i >= 0; i--) {
            nodeStack.push(children[i]);
        }
        if (curNode.nodeType === document.TEXT_NODE && curNode !== text) {
            offset += curNode.textContent.length;
        } else if (curNode.nodeType === document.TEXT_NODE) {
            break;
        }
        curNode = nodeStack.pop();
    }
    // console.log('getTextPreOffset', offset)
    return offset;
}
function getTextChildByOffset(parent, offset) {
    var nodeStack = [];
    var curNode = parent;
    var curOffset = 0;
    var startOffset = 0;
    while (curNode) {
        var children = curNode.childNodes;
        for (var i = children.length - 1; i >= 0; i--) {
            nodeStack.push(children[i]);
        }
        if (curNode.nodeType === document.TEXT_NODE) {
            startOffset = offset - curOffset;
            curOffset += curNode.textContent.length;
            if (curOffset >= offset) {
                break;
            }
        }
        curNode = nodeStack.pop();
    }
    if (!curNode) {
        curNode = parent;
    }
    return { node: curNode, offset: startOffset };
}
// #endregion

//#region onselectionchange
function listenerOnselectionchange() {

    document.onselectionchange = function () {
        var coord = getSelectionArea();
        coord && window.webkit.messageHandlers.MOJiReadingArticleDetailVCChangeSelectedCoordinate.postMessage(JSON.stringify(coord));

        //TODO 阅读器：处理跨页划选句子
        // if (EPUBcfi) {
        //     let range = getDomRange()
        //     if (range) {
        //         let endContainer = range.endContainer

        //         var bodyStyle = document.body.currentStyle || window.getComputedStyle(document.body)
        //         var columnWidth = parseInt(bodyStyle.columnWidth, 10)

        //         if (coord.width > columnWidth) {
        //             setScrollEnable(true)
        //             let pageIndex = getPageIndexByNodeOrRange(endContainer)
        //             if (currentPageIndex != pageIndex) {
        //                 scrollToPageIndex(pageIndex)
        //             }
        //         } else {
        //             setScrollEnable(false)
        //         }
        //     } else {
        //         setScrollEnable(true)
        //     }
        // }
    };
}

function setScrollEnable(allow) {
    if (currentEnableScroll == value) return;

    if (allow) {
        document.body.style.overflowX = 'auto';
        document.body.style.overflowY = 'hidden';
        req(Api.setScrollEnable, true);
    } else {
        document.body.style.overflowX = 'hidden';
        document.body.style.overflowY = 'hidden';
        req(Api.setScrollEnable, false);
    }

    currentEnableScroll = allow;
}

function getSelectionArea() {
    var selection = window.getSelection();
    if (!selection.isCollapsed) {
        return selection.getRangeAt(0).getBoundingClientRect();
    }
    return null;
}
//#endregion